<?php
?>
<head>
	<link href="../css/layout.css">
</head>
<body>
	<header class="header">
		<div id="logo">
			<a href="localhost/slush"><img src="img/logo/logo.png"></a>
			</div>
			<nav><ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="profile.php">Profile</a></li>
				<li><a href="settings.php">Setting</a></li>
				<li><a href="logout.php">Log Out</a></li>
			</ul></nav>
	</header>
</body>
