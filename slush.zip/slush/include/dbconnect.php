<?php
	$system = "localhost";
	$usr = "root";
	$pwd = "";
	$db = "slush";

	$conn = mysqli_connect($system,$usr,$pwd,$db);	
?>